#ifndef GAME3_H
#define GAME3_H

#include <QtGui>

/**
* \file game3.h
* \brief Dots and Lines class
*
* This is the class for the gameplay of the Dots and Lines game.
* \author Rita Aoun
* \author Rawan Moukalled
*/
class Game3 : public QWidget
{
    Q_OBJECT
public:
    /**
    * \brief Default constructor
    */
    explicit Game3(QWidget *parent = 0);

    /**
    * \brief Destrucor
    */
    virtual ~Game3();

signals:

public slots:
    /**
    * \brief Slot to go back to the games main menu when pressing Exit
    */
    void goToMainMenu();

private:
    QLabel *m_title; ///< Game title
    QPushButton *m_exit; ///< Button to save and exit
    QVBoxLayout *m_Game3Layout; ///< Layout of widget

    /**
    * \brief Sets the different graphic items in one layout for the game
    */
    void setGame3Layout();
};

#endif // Game3_H
