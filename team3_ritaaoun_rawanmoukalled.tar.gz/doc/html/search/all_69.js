var searchData=
[
  ['inlinedistanceto',['inLineDistanceTo',['../classSheep1.html#aa25f6b89d1a6de8f0c0afd7885176777',1,'Sheep1']]],
  ['isinline',['isInLine',['../classSheep1.html#a5bfd6e9f199c39fbc6daa3a679905653',1,'Sheep1']]]
];
